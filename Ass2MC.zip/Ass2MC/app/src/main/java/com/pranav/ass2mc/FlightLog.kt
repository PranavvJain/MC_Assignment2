package com.pranav.ass2mc.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "flightlog")
data class FlightLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val flightNumber: String,
    val departure: String,
    val arrival: String,
    val depTimeMillis: Long,
    val arrTimeMillis: Long,
    val durationMin: Int
)
