package com.pranav.ass2mc.models

data class FlightResponse(
    val data: List<FlightData>
)

data class FlightData(
    val flight_status: String?,
    val flight: FlightInfo?,
    val live: LiveInfo?
)

data class FlightInfo(
    val number: String?
)

data class LiveInfo(
    val latitude: Double?,
    val longitude: Double?,
    val updated: String?
)
