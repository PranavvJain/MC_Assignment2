package com.pranav.ass2mc.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.pranav.ass2mc.models.FlightHistory

@Dao
interface FlightHistoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(flights: List<FlightHistory>)

    @Query("SELECT AVG(duration_minutes) FROM flighthistory")
    suspend fun getAverageDuration(): Double
}
