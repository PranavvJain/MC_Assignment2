package com.pranav.ass2mc.network

import com.pranav.ass2mc.models.FlightResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface AviationApi {
    @GET("flights")
    fun getFlightDetails(
        @Query("access_key") apiKey: String,
        @Query("flight_iata") flightNumber: String
    ): Call<FlightResponse>
}
