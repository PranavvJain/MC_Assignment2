package com.pranav.ass2mc.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.pranav.ass2mc.db.AppDatabase
import com.pranav.ass2mc.models.FlightLog
import com.pranav.ass2mc.network.RetrofitClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class FlightWorker(
    context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    private val apiKey = "YOUR_API_KEY" // 🔑 Replace with your actual key

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val dao = AppDatabase.getDatabase(applicationContext).flightLogDao()
            val flights = listOf("AI202", "AI203", "AI204")

            for (flight in flights) {
                val response = RetrofitClient.instance.getFlightDetails(apiKey, flight).execute()
                val flightData = response.body()?.data?.firstOrNull()

                if (flightData != null) {
                    // Dummy estimate: simulate 90 mins for now (can be replaced with real time data)
                    val depTime = System.currentTimeMillis()
                    val arrTime = depTime + (90 * 60 * 1000) // +90 mins
                    val durationMin = ((arrTime - depTime) / 60000).toInt()

                    val log = FlightLog(
                        flightNumber = flight,
                        departure = "DEL", // Placeholder
                        arrival = "BOM",   // Placeholder
                        depTimeMillis = depTime,
                        arrTimeMillis = arrTime,
                        durationMin = durationMin
                    )

                    dao.insertFlight(log)
                }
            }

            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure()
        }
    }
}
