package com.pranav.ass2mc

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.pranav.ass2mc.models.FlightResponse
import com.pranav.ass2mc.network.RetrofitClient
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.pranav.ass2mc.models.FlightHistory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var input: EditText
    private lateinit var statusText: TextView
    private lateinit var handler: Handler
    private lateinit var flightNumber: String
    private val apiKey = "976108fe5b7c1729a78a66a340729668"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        input = findViewById(R.id.flightNumberInput)
        statusText = findViewById(R.id.flightStatusText)
        val button: Button = findViewById(R.id.trackButton)
        val avgButton: Button = findViewById(R.id.averageButton)
        val avgResultText: TextView = findViewById(R.id.averageResult)

        handler = Handler(Looper.getMainLooper())

        button.setOnClickListener {
            flightNumber = input.text.toString()
            if (flightNumber.isNotEmpty()) {
                fetchFlight()
                handler.removeCallbacksAndMessages(null)
                handler.postDelayed(updateTask, 60000)
            } else {
                statusText.text = "Please enter a flight number."
            }
        }

        // ✅ Q2 button to show average time from JSON
        avgButton.setOnClickListener {
            lifecycleScope.launch {
                val avg = withContext(Dispatchers.IO) {
                    calculateAverageDuration()
                }
                avgResultText.text = "Average Flight Duration: $avg minutes"
            }
        }
    }

    private val updateTask = object : Runnable {
        override fun run() {
            fetchFlight()
            handler.postDelayed(this, 60000)
        }
    }

    private fun fetchFlight() {
        val call = RetrofitClient.instance.getFlightDetails(apiKey, flightNumber)

        call.enqueue(object : Callback<FlightResponse> {
            override fun onResponse(call: Call<FlightResponse>, response: Response<FlightResponse>) {
                val flightData = response.body()?.data?.firstOrNull()
                if (flightData != null && flightData.live != null) {
                    val info = """
                        Flight: ${flightData.flight?.number}
                        Status: ${flightData.flight_status}
                        Latitude: ${flightData.live.latitude}
                        Longitude: ${flightData.live.longitude}
                        Last Updated: ${flightData.live.updated}
                    """.trimIndent()
                    statusText.text = info
                } else {
                    statusText.text = "Flight info not available. Try again later."
                }
            }

            override fun onFailure(call: Call<FlightResponse>, t: Throwable) {
                statusText.text = "Error fetching flight data: ${t.message}"
            }
        })
    }

    private fun loadFlightHistoryFromAssets(): List<FlightHistory> {
        val json = applicationContext.assets.open("flight_data.json")
            .bufferedReader().use { it.readText() }

        val type = object : TypeToken<List<FlightHistory>>() {}.type
        return Gson().fromJson(json, type)
    }

    private fun calculateAverageDuration(): Int {
        val history = loadFlightHistoryFromAssets()
        val total = history.sumOf { it.duration_minutes }
        return total / history.size
    }
}
