package com.pranav.ass2mc.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.pranav.ass2mc.models.FlightLog

@Dao
interface FlightLogDao {

    @Insert
    suspend fun insertFlight(log: FlightLog)

    @Query("SELECT AVG(durationMin) FROM flightlog WHERE flightNumber = :flightNumber")
    suspend fun getAverageDuration(flightNumber: String): Double?
}
