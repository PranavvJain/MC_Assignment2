package com.pranav.ass2mc.models

data class FlightHistory(
    val id: String,
    val aircraft: String,
    val origin: String,
    val destination: String,
    val departure: String,
    val arrival: String,
    val duration_minutes: Int,
    val date: String
)
